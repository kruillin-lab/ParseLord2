﻿using System;

namespace ParseLord2.Attributes;

[AttributeUsage(AttributeTargets.Field)]
internal class AutoActionAttribute : Attribute
{
    public bool IsAoE;
    public bool IsHeal;
    internal AutoActionAttribute(bool isAoE, bool isHeal) 
    { 
        IsAoE = isAoE;
        IsHeal = isHeal;
    }
}