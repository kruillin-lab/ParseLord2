# Phase 7: SAM AoE Gold Planner

## Implementation Summary

Phase 7 implements the AoE variant of the SAM Gold Planner, completing SAM's coverage across both single-target and AoE scenarios. This mirrors what was done for DRG in Phase 5A and further validates the architecture's scalability.

## What Changed

### Files Created
- `AutoRotation/Planner/Samurai/SamAoeGcdPlanner.cs` - SAM AoE GCD planner

### Files Modified
- `Combos/PvE/SAM/SAM.cs` - Added SAM_AOE_GoldPlanner combo class
- `Combos/CustomComboPreset.cs` - Added SAM_AOE_GoldPlanner preset enum (15151)

## Core Implementation

### 1. SAM AoE GCD Planner (`SamAoeGcdPlanner.cs`)

The AoE GCD planner implements a simplified Sen-based rotation for multi-target scenarios:

**Two Combo Branches from Fuga:**
1. **Mangetsu Branch:** Fuga → Mangetsu
   - Grants **Getsu** Sen
   - Refreshes **Fugetsu** buff (13% damage increase)
   
2. **Oka Branch:** Fuga → Oka
   - Grants **Ka** Sen
   - Refreshes **Fuka** buff (13% speed increase)

**Note:** No Yukikaze (Setsu) in AoE rotation - only need 2 Sen types.

**Iaijutsu Spender:**
- **2-3 Sen:** Tenka Goken (AoE finisher, 400 potency per target)
- **Follow-up:** Tsubame-gaeshi → Kaeshi Goken (repeats Tenka Goken)

**Decision Logic:**
```
Priority 1: Use Tenka Goken if 2-3 Sen ready
Priority 2: Use Tsubame-gaeshi (Kaeshi Goken) if ready
Priority 3: Continue active combo
Priority 4: Start new combo based on:
    - Refresh Fugetsu if < 6s remaining → Mangetsu
    - Refresh Fuka if < 6s remaining → Oka
    - Build missing Sen (prefer Mangetsu > Oka)
    - Default to Mangetsu
```

**Comparison to ST:**
- **Simpler:** 2 branches vs 3 (no Yukikaze/Setsu)
- **Faster Loop:** 2-step combos vs mixed 2-step and 3-step
- **Lower Sen Requirement:** 2 Sen acceptable for Tenka vs 3 Sen required for Midare
- **Same Buff Logic:** Fuka/Fugetsu maintenance identical

### 2. oGCD Behavior in AoE Mode

**Current Behavior (Phase 7):**
- oGCD selection uses the **same planner** as ST (`SamOgcdPlanner`)
- Most SAM oGCDs work identically for ST and AoE:
  - **Ikishoten:** Kenki generation + burst buff
  - **Guren:** 25 Kenki AoE spender (actually benefits from multiple targets)
  - **Shoha:** Meditation stack spender (AoE ability)
  - **Meikyo Shisui:** Free Sen generation
  - **Kyuten:** 25 Kenki AoE spender (AoE-specific, but not in current planner)

**Note on Kyuten:**
Current planner uses **Shinten** (ST spender) for Kenki management. In a future enhancement, the planner could:
- Add target count awareness
- Use Kyuten (AoE) when `targetCountEstimate >= 3`
- Use Shinten (ST) when `targetCountEstimate == 1`

This is a minor optimization and not critical for Phase 7.

### 3. SAM_AOE_GoldPlanner Combo Class

Follows the same integration pattern as SAM ST and DRG AoE:

```csharp
internal class SAM_AOE_GoldPlanner : CustomCombo
{
    protected internal override Preset Preset => Preset.SAM_AOE_GoldPlanner;
    
    private static readonly SamAoeGcdPlanner Planner = new();
    private static readonly SamOgcdPlanner OgcdPlanner = new();
    
    protected override uint Invoke(uint actionID)
    {
        // 1. Build planner context (targetCountEstimate: 3 for AoE)
        // 2. Get next GCD from AoE planner
        // 3. Try select oGCD (same logic as ST)
        // 4. Record trace to Debug UI
        // 5. Return oGCD if selected, else GCD
    }
}
```

**Target Count Estimate:**
- ST: `targetCountEstimate: 1`
- AoE: `targetCountEstimate: 3`

## AoE Rotation Structure

### 2-Step Loop (Sen Generation)
```
1. Fuga (base) / Fuko (when Tendo buff active)
   ↓
2a. Mangetsu (grants Getsu, refreshes Fugetsu)
   OR
2b. Oka (grants Ka, refreshes Fuka)
   ↓ (loop back to step 1)
```

### Sen Spending
```
At 2+ Sen:
→ Tenka Goken (AoE Iaijutsu)
  ↓
→ Tsubame-gaeshi → Kaeshi Goken (AoE follow-up)
  ↓ (back to Sen generation)
```

### Buff Priority
Maintain both buffs by alternating Mangetsu and Oka:
1. First loop: Mangetsu (Fugetsu)
2. Second loop: Oka (Fuka)
3. Use Tenka Goken at 2 Sen
4. Repeat, refreshing buffs as needed

## Preset Configuration

**Enum ID:** `SAM_AOE_GoldPlanner = 15151`

**Attributes:**
- `[ReplaceSkill(SAM.Fuga, SAM.Fuko)]` - Replaces Fuga button
- `[ConflictingCombos(SAM_AoE_SimpleMode, SAM_AoE_AdvancedMode)]` - Mutually exclusive
- `[AdvancedCombo]` - Marked as advanced feature
- `[AutoAction(false, false)]` - Not auto-enabled

**UI Location:**
Appears in SAM combo list after ST Gold Planner (15150)

## Debug Trace Integration

**Trace Key:** `"SAM_AOE_GoldPlanner"`

**Trace Label:** `"SAM AoE Gold Planner"`

The trace UI will show:
- Planned next GCD (Fuga/Fuko/Mangetsu/Oka/TenkaGoken)
- Selected oGCD (if any)
- Target count estimate (3)
- Burst phase (currently Neutral for SAM)
- Weave window status
- oGCD candidate list with allowed/blocked status and scores

## Testing Recommendations

### Basic AoE Rotation
1. Enable SAM_AOE_GoldPlanner preset
2. Engage multiple enemies (3+)
3. Verify GCD sequence alternates between Mangetsu and Oka
4. Confirm Tenka Goken executes at 2-3 Sen
5. Verify Kaeshi Goken (Tsubame-gaeshi) follows Tenka Goken
6. Check Tendo buff → Fuko replacement works

### Buff Management
1. Watch Fugetsu/Fuka timers
2. Confirm buffs refresh before expiring (~6s threshold)
3. Verify Sen builds correctly (Mangetsu=Getsu, Oka=Ka)
4. Check alternating pattern maintains both buffs

### oGCD Integration
1. Verify Ikishoten fires during AoE
2. Confirm Guren uses Kenki (should be prioritized for AoE)
3. Check Shoha fires at 3 Meditation stacks
4. Verify Meikyo Shisui grants free Sen
5. Confirm Kenki management works (Shinten or Kyuten)

### Tsubame-gaeshi Follow-up
1. Verify Kaeshi Goken Ready buff detection
2. Confirm Tsubame executes after Tenka Goken
3. Check that Tenka doesn't overwrite existing Tsubame buffs

### Debug Trace
1. Open Debug tab → Hybrid Planner Trace
2. Verify "SAM AoE Gold Planner" trace appears
3. Check GCD decisions show correct Sen/buff logic
4. Review oGCD candidates and scoring

### Edge Cases
1. Test with Meikyo Shisui active (free Sen grants)
2. Verify low-level rotation (pre-Tenka Goken)
3. Test combo break recovery
4. Check Tendo buff timing (Fuko vs Fuga)

## Comparison: DRG vs SAM AoE

| Aspect | DRG AoE | SAM AoE |
|--------|---------|---------|
| **GCD Loop** | 3 GCDs (linear) | 2 GCDs (branching) |
| **Branching** | No | Yes (Mangetsu vs Oka) |
| **Resource System** | None (simple combo) | Sen (2 types) |
| **Buff Management** | Power Surge only | Fuka + Fugetsu |
| **Finisher** | CoerthanTorment (combo) | Tenka Goken (Sen spender) |
| **Follow-up** | None | Kaeshi Goken |
| **Complexity** | Low | Medium |

## Architecture Notes

### Code Reuse Across Jobs
Both DRG and SAM AoE planners share:
- **oGCD Planner:** Job-specific but same pattern
- **Burst Detection:** PlannerContext (job-agnostic for now)
- **Trace System:** Fully generic
- **Context Building:** Same PlannerContext infrastructure
- **Integration Pattern:** Identical combo class structure

### Job-Specific Differences
- **DRG AoE:** Simple linear 3-step combo, no branching
- **SAM AoE:** Branching 2-step combos with Sen/buff management

Despite these differences, both use identical infrastructure.

### Target Count Awareness
Currently hardcoded in combo class (3 for AoE). Future enhancement: dynamic detection.

## Performance Expectations

**GCD Accuracy:**
- Should execute perfect Mangetsu/Oka alternation
- Buffs should never drop (refreshed at 6s threshold)
- Sen should build efficiently (2 Sen for Tenka Goken)

**oGCD Usage:**
- Identical to SAM ST Gold Planner
- Phase 6 logic applies (Kenki management, Meditation stacks, etc.)

**DPS Parity:**
- Should match or exceed SAM AoE Advanced Mode
- More consistent buff uptime due to deterministic rotation

## Architecture Validation Update

### ✅ **Further Proven: Architecture Scales Across AoE Variants**

**Evidence:**
- SAM AoE added with ~100 lines of new GCD planner code
- Zero modifications to infrastructure needed
- oGCD planner fully reused from ST
- Trace system works identically
- Integration pattern unchanged

**Jobs Completed:**
- **DRG ST** ✅ (10-GCD dual-branch combo)
- **DRG AoE** ✅ (3-GCD linear combo)
- **SAM ST** ✅ (Sen-based branching with 3 paths)
- **SAM AoE** ✅ (Sen-based branching with 2 paths)

**Code Statistics (Phase 7):**
- New Code: ~100 lines (1 GCD planner file)
- Modified Code: ~60 lines (combo class + preset)
- Reused Code: ~1000+ lines (all infrastructure)
- **Reuse Ratio: ~90%**

## Future Iteration Opportunities

### Phase 8+ Candidates
- **Burst Detection Refactor:** Job-specific strategies for SAM
- **Target Count Detection:** Auto-switch ST/AoE based on enemy count
- **Kyuten Integration:** Use AoE Kenki spender when targetCountEstimate >= 3
- **Third Job:** MNK, NIN, or RPR to further validate scalability
- **Config System:** User-configurable thresholds and priorities
- **Opener Integration:** Pre-pull sequences for both jobs

### SAM-Specific Enhancements
- **Ogi Namikiri Logic:** Integrate Ikishoten buff follow-up
- **Meikyo Optimization:** Smarter Sen selection during free Sen windows
- **Hagakure Logic:** Sen dump for Kenki when beneficial
- **Zanshin Integration:** Execute Zanshin Ready buff spender

## Known Limitations

### SAM AoE Specific
1. **No Kyuten:** Uses Shinten (ST) instead of Kyuten (AoE) for Kenki spending
2. **No Hagakure:** Sen dump logic not implemented
3. **No Ogi Namikiri:** Ikishoten follow-up not implemented
4. **No Opener:** Starts rotation immediately

### Architecture-Wide (Unchanged)
1. **Burst Detection:** Still DRG-specific, SAM always shows Neutral
2. **No Dynamic Target Count:** Can't auto-switch between ST/AoE planners
3. **Hardcoded Thresholds:** Buff refresh times, Sen requirements, etc.

## Summary

Phase 7 successfully completes SAM Gold Planner coverage (ST + AoE) and further validates the Hybrid Planner architecture's scalability. The implementation required minimal new code (~100 lines) while reusing ~90% of the existing infrastructure.

**Key Achievements:**
- ✅ SAM AoE rotation implemented with Sen-based branching
- ✅ Full oGCD planner reuse from SAM ST
- ✅ Trace system works identically
- ✅ Integration pattern proven consistent across 4 variants (2 jobs × 2 modes)
- ✅ Architecture scales efficiently (90% code reuse)

**Current Coverage:**
- **DRG:** ST + AoE ✅
- **SAM:** ST + AoE ✅
- **Total:** 4 planner variants implemented

The foundation is now solid for rapid expansion to additional jobs (MNK, NIN, RPR, etc.) with high confidence in the architecture's flexibility and maintainability.
