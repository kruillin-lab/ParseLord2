﻿namespace ParseLord2.Extensions;

internal static class ByteExtensions
{

}