# Vision Cone Feature

## Summary

Implemented configurable vision cone filtering for DPS auto-rotation targeting. Targets are only eligible for attack if they're within a specified angle from where the player is facing.

## What Changed

### Files Modified
1. **AutoRotation/AutoRotationConfig.cs**
   - Added `EnableVisionCone` bool to DPSSettings
   - Added `VisionConeAngle` float to DPSSettings (default: 120°)

2. **CustomCombo/Functions/Target.cs**
   - Added `IsTargetInVisionCone()` function
   - Calculates angle from player facing direction to target
   - Returns true if target is within cone angle

3. **AutoRotation/AutoRotationController.cs**
   - Updated DPSTargeting.Query() to include vision cone check
   - Only filters when `EnableVisionCone` is true

4. **Window/Tabs/AutoRotationTab.cs**
   - Added UI checkbox for "Enable Vision Cone"
   - Added slider for "Vision Cone Angle" (30-360°)
   - Slider only visible when vision cone is enabled

## How It Works

### Vision Cone Calculation

The vision cone is centered on the player's facing direction (where they're looking):

```
          ← Player Facing Direction →
                    ___
                   /   \
                  /     \    ← Vision Cone
                 /       \
        Target  •   ✓    × Target
       (in cone)       (out of cone)
```

**Angle Calculation:**
1. Get player's rotation (facing direction)
2. Calculate rotation from player to target
3. Find the difference between them
4. Normalize to -180° to +180° range
5. Check if absolute angle ≤ half of cone angle

**Examples:**
- **120° cone**: Covers 60° to each side (typical narrow cone)
- **180° cone**: Covers 90° to each side (half-circle, left/right vision)
- **240° cone**: Covers 120° to each side (wide cone, slight blind spot behind)
- **360° cone**: No filtering (everything visible)

### Integration

**DPS Targeting Query:**
```csharp
private static bool Query(IGameObject x) =>
    x is IBattleChara chara &&
    !chara.IsDead &&
    chara.IsTargetable &&
    chara.IsHostile() &&
    IsInRange(chara, cfg.DPSSettings.MaxDistance) &&
    // ... other checks ...
    (!cfg.DPSSettings.EnableVisionCone || IsTargetInVisionCone(chara, cfg.DPSSettings.VisionConeAngle));
```

**Behavior:**
- When `EnableVisionCone = false`: All targets pass (no filtering)
- When `EnableVisionCone = true`: Only targets within cone angle pass

## Configuration

### In-Game UI

Location: **ParseLord2 Settings → Auto-Rotation Tab**

**Enable Vision Cone** checkbox:
- Toggles vision cone filtering on/off
- Default: Disabled

**Vision Cone Angle** slider (when enabled):
- Range: 30° - 360°
- Default: 120°
- Step: 1°

### Config File

Stored in `AutoRotationConfig.DPSSettings`:

```json
{
  "DPSSettings": {
    "EnableVisionCone": false,
    "VisionConeAngle": 120.0
  }
}
```

## Use Cases

### Combat Scenarios

**Dungeon Pulls:**
- Set cone to 120-180° to focus on enemies in front
- Prevents attacking adds behind you during repositioning
- Helps with cleave mechanics (don't hit targets you shouldn't)

**Boss Fights:**
- Set cone to 180° to maintain focus on frontal targets
- Useful when adds spawn behind but you want to stay on boss
- Prevents targeting switches during positional movement

**PvP:**
- Set cone to 90-120° for narrow focus
- Only engage targets you're actively facing
- Better control over target selection in chaotic fights

**Open World:**
- Set cone to 240-270° for wide coverage
- Still maintains some directionality
- Good for quest mob hunting while moving

### Recommended Angles

| Scenario | Recommended Angle | Reasoning |
|----------|-------------------|-----------|
| **Single Target Focus** | 90-120° | Narrow cone, less target switching |
| **Dungeon Trash** | 150-180° | Wide enough for AoE packs |
| **Boss with Adds** | 120-150° | Focus boss while allowing nearby adds |
| **PvP Duels** | 90° | Tight focus, manual control |
| **Open World Farming** | 240-300° | Wide coverage, less micromanagement |
| **Disable** | 360° or Off | Full 360° vision (default behavior) |

## Technical Details

### Positional Math

The `IsTargetInVisionCone()` function uses the same math as positional checks but reversed:

**Positional Check (rear/flank):**
- Calculates angle from TARGET to PLAYER
- Determines where player is relative to target

**Vision Cone Check:**
- Calculates angle from PLAYER to TARGET
- Determines where target is relative to player's facing

**Formula:**
```csharp
float rotation = GetRotation(player.Position, target.Position) - player.Rotation;
float angleDegrees = ToDegrees(rotation);

// Normalize to -180 to +180
if (angleDegrees > 180f)
    angleDegrees -= 360f;

// Check if within cone
float halfCone = coneAngleDegrees / 2f;
return Math.Abs(angleDegrees) <= halfCone;
```

### Performance

**Overhead:**
- One additional check per target per frame
- Minimal: 2 subtractions, 1 multiplication, 1-2 comparisons
- Only runs when `EnableVisionCone = true`
- Negligible impact on frame time

**Optimization:**
- 360° cone short-circuits (returns true immediately)
- Query() uses short-circuit evaluation (vision cone is last check)
- Targets failing earlier checks never reach vision cone logic

### Edge Cases

**Zero or Negative Angle:**
- Slider clamped to minimum 30°
- Any value < 30° treated as 30° (small narrow cone)

**Exactly 360°:**
- Short-circuit return true (no filtering)
- Same as disabling vision cone

**Player Not Loaded:**
- Returns false (no valid player)
- Prevents null reference errors

**Target Is Self:**
- Would pass (angle to self is 0)
- But other checks prevent self-targeting

## Testing Recommendations

### Basic Functionality
1. Enable vision cone with 120° angle
2. Face a target dummy and verify it attacks
3. Turn 90° away and verify it stops attacking
4. Turn back and verify it resumes

### Angle Verification
1. Set angle to 90° (narrow)
2. Position targets at 45°, 90°, and 135° from facing
3. Verify: 45° attacks, 90° attacks, 135° doesn't attack

### Dynamic Combat
1. Enable in dungeon with 150° angle
2. Verify targets in front are prioritized
3. Spin around and verify target switches based on facing

### UI Integration
1. Toggle checkbox on/off - verify targeting behavior changes
2. Adjust slider - verify new angle takes effect immediately
3. Disable checkbox - verify all targets become valid again

## Known Limitations

### Current Implementation
1. **DPS Only:** Vision cone only applies to DPS targeting, not healer targeting
2. **No Preview:** No visual indicator of cone in-game (blind adjustment)
3. **Config Persistence:** Settings saved per character (not global)
4. **Static During Combat:** Angle doesn't auto-adjust based on situation

### Future Enhancements
- Visual cone overlay (debug mode)
- Per-job cone angle presets
- Auto-adjust cone based on combat role (tank vs DPS)
- Healer targeting cone integration
- Separate cone angles for ST vs AoE modes

## Implementation Notes

### Design Decisions

**Why Default to Disabled?**
- Non-breaking change for existing users
- Allows users to opt-in when they understand the feature
- Default 120° is conservative but useful when enabled

**Why 30-360° Range?**
- 30° is the narrowest practical cone (very focused)
- 360° = full circle (effectively disabling the filter)
- Allows full spectrum from ultra-narrow to disabled

**Why Last in Query Chain?**
- Vision cone is the most subjective filter
- Other filters (dead, invincible, LoS) are hard requirements
- If earlier checks fail, skip unnecessary angle calculation

### Integration with Existing Systems

**Compatible With:**
- ✅ All DPS rotation modes (Manual, Highest, Nearest, etc.)
- ✅ FATE/Quest priority targeting
- ✅ Combat/non-combat preference
- ✅ Distance and LoS checks
- ✅ Manual target override

**Not Compatible With:**
- ❌ Healer targeting (not implemented)
- ❌ Tank targeting (not implemented)

## Summary

This feature provides fine-grained control over auto-rotation targeting based on player facing direction. It's particularly useful for:
- Maintaining focus during repositioning
- Preventing unintended target switches
- Creating more deliberate combat behavior
- Reducing "spinning attacks everything" chaos

The implementation is lightweight, configurable, and non-invasive to existing targeting systems.
