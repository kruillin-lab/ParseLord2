namespace ParseLord2.Combos.PvE;

internal partial class DOL
{
    internal static class Config
    {
        //Config goes here

        internal static void Draw(Preset preset)
        {
            //switch (preset)
            //{
            //    //Presets
            //}
        }
    }
}
