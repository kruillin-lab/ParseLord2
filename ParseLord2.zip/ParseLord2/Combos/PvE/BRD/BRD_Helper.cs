﻿#region Dependencies
using Dalamud.Game.ClientState.JobGauge.Enums;
using Dalamud.Game.ClientState.JobGauge.Types;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.ClientState.Statuses;
using ECommons.Logging;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using System;
using System.Collections.Frozen;
using System.Collections.Generic;
using System.Linq;
using ParseLord2.Core;
using ParseLord2.CustomComboNS;
using ParseLord2.CustomComboNS.Functions;
using ParseLord2.Extensions;
using static ParseLord2.Combos.PvE.BRD.Config;
using static ParseLord2.CustomComboNS.Functions.CustomComboFunctions;
#endregion

namespace ParseLord2.Combos.PvE;
internal partial class BRD
{
    #region Variables
    internal static readonly FrozenDictionary<uint, ushort> PurpleList = new Dictionary<uint, ushort>
    {
        { VenomousBite, Debuffs.VenomousBite },
        { CausticBite, Debuffs.CausticBite }
    }.ToFrozenDictionary();
    
    internal static readonly FrozenDictionary<uint, ushort> BlueList = new Dictionary<uint, ushort>
    {
        { Windbite, Debuffs.Windbite },
        { Stormbite, Debuffs.Stormbite }
    }.ToFrozenDictionary();
    
    
    
    // Gauge Stuff
    internal static BRDGauge? gauge = GetJobGauge<BRDGauge>();
    internal static int SongTimerInSeconds => gauge.SongTimer / 1000;
    internal static float SongTimerSeconds => gauge.SongTimer / 1000f;
    internal static bool SongNone => gauge.Song == Song.None;
    internal static bool SongWanderer => gauge.Song == Song.Wanderer;
    internal static bool SongMage => gauge.Song == Song.Mage;
    internal static bool SongArmy => gauge.Song == Song.Army;

// Advanced BRD minimal trace (optional; gated by BRD_Adv_Debug)
// NOTE: This is intentionally throttled to avoid log spam (and the DPS loss / hitching that comes with it).
private static readonly Queue<string> _advTrace = new();
private static long _advTraceLastMs;
private static string _advTraceLastMsg = string.Empty;
private static int _advTraceSuppressed;

internal static IReadOnlyList<string> AdvTraceSnapshot() => _advTrace.ToArray();

internal static void AdvTrace(string message)
{
    if (!BRD_Adv_Debug) return;

    var now = Environment.TickCount64;
    // If the message is identical and we're within the throttle window, suppress it.
    if (message == _advTraceLastMsg && (now - _advTraceLastMs) < 750)
    {
        _advTraceSuppressed++;
        return;
    }

    // If we suppressed spam, emit a single summary line before the next real line.
    if (_advTraceSuppressed > 0)
    {
        var summary = $"[BRD.Adv] (suppressed {_advTraceSuppressed} duplicate trace lines)";
        if (_advTrace.Count >= 50) _advTrace.Dequeue();
        _advTrace.Enqueue(summary);
        try { PluginLog.Information(summary); } catch { /* ignore */ }
        _advTraceSuppressed = 0;
    }

    _advTraceLastMs = now;
    _advTraceLastMsg = message;

    var line = $"[BRD.Adv] {message}";
    if (_advTrace.Count >= 50) _advTrace.Dequeue();
    _advTrace.Enqueue(line);
    try { PluginLog.Information(line); } catch { /* ignore */ }
}

//Dot Management

    internal static IStatus? Purple => GetStatusEffect(Debuffs.CausticBite, CurrentTarget) ?? GetStatusEffect(Debuffs.VenomousBite, CurrentTarget);
    internal static IStatus? Blue => GetStatusEffect(Debuffs.Stormbite, CurrentTarget) ?? GetStatusEffect(Debuffs.Windbite, CurrentTarget);
    internal static float PurpleRemaining => Purple?.RemainingTime ?? 0;
    internal static float BlueRemaining => Blue?.RemainingTime ?? 0;
    internal static bool DebuffCapCanPurple => CanApplyStatus(CurrentTarget, Debuffs.CausticBite) || CanApplyStatus(CurrentTarget, Debuffs.VenomousBite);
    internal static bool DebuffCapCanBlue => CanApplyStatus(CurrentTarget, Debuffs.Stormbite) || CanApplyStatus(CurrentTarget, Debuffs.Windbite);

    //Useful Bools
    internal static bool BardHasTarget => HasBattleTarget();
    // Bard is extremely sensitive to missed weave windows; allow delayed weave for throughput.
    internal static bool CanBardWeave => CanWeave() || CanDelayedWeave();
    internal static bool CanWeaveDelayed => CanDelayedWeave();
    internal static bool CanIronJaws => LevelChecked(IronJaws);
    internal static bool BuffTime => GetCooldownRemainingTime(RagingStrikes) < 2.7;
    internal static bool BuffWindow => HasStatusEffect(Buffs.RagingStrikes) && 
                                       (HasStatusEffect(Buffs.BattleVoice) || !LevelChecked(BattleVoice)) &&
                                       (HasStatusEffect(Buffs.RadiantFinale) || !LevelChecked(RadiantFinale));

    //Buff Tracking
    internal static float RagingCD => GetCooldownRemainingTime(RagingStrikes);
    internal static float BattleVoiceCD => GetCooldownRemainingTime(BattleVoice);
    internal static float EmpyrealCD => GetCooldownRemainingTime(EmpyrealArrow);
    internal static float RadiantCD => GetCooldownRemainingTime(RadiantFinale);
    internal static float RagingStrikesDuration => GetStatusEffectRemainingTime(Buffs.RagingStrikes);
    internal static float RadiantFinaleDuration => GetStatusEffectRemainingTime(Buffs.RadiantFinale);

    // Charge Tracking
    internal static uint RainOfDeathCharges => LevelChecked(RainOfDeath) ? GetRemainingCharges(RainOfDeath) : 0;
    internal static uint BloodletterCharges => GetRemainingCharges(Bloodletter);

    #endregion

    #region Functions

        #region Action Status Helpers
        /// <summary>
        /// ActionReady() intentionally treats some non-zero ActionStatus codes as "ready".
        /// For Bard, Radiant Finale is notorious for reporting ready even when it will fail.
        /// Use a strict status check (status == 0) for actions that must not starve the weave slot.
        /// </summary>
        internal static unsafe bool StrictActionReady(uint actionId)
        {
            uint hookedId = OriginalHook(actionId);
            // ActionManager status == 0 means fully usable now.
            return ActionManager.Instance()->GetActionStatus(ActionType.Action, hookedId) == 0;
        }

        internal static bool CanUseRadiantFinaleNow()
        {
            if (!LevelChecked(RadiantFinale))
                return false;

            if (!InCombat())
                return false;

            // Must be a real weave window.
            if (!CanWeaveDelayed)
                return false;

            // Don't try to re-cast when Encore is ready or Finale buff is already up.
            if (HasStatusEffect(Buffs.RadiantEncoreReady) || HasStatusEffect(Buffs.RadiantFinale))
                return false;

            // Hard gate: must be truly usable (status == 0) to avoid starvation.
            return StrictActionReady(RadiantFinale);
        }
        #endregion

        #region Pooling
        // Pooled Apex Logic
        internal static bool UsePooledApex()
        {
            if (gauge.SoulVoice >= 80)
            {
                if (BuffWindow && RagingStrikesDuration < 18 || RagingCD >= 50 && RagingCD <= 62)
                    return true;
            }
            return false;
        }
    

        // Pitch Perfect Logic
        internal static bool PitchPerfected()
        {
            if (!LevelChecked(PitchPerfect))
                return false;

            // Ruthless Pitch Perfect:
            // - Always fire at 3 stacks.
            // - Fire at 2 stacks if we're in buffs, near song end, or an Empyreal weave is coming up (to keep the oGCD lane clean).
            // - Fire at 1 stack only if the song is basically ending (avoid losing a stack).
            var rep = gauge.Repertoire;
            if (rep >= 3)
                return true;

            // Wanderer's only; Pitch Perfect isn't available outside it, but keep the guard cheap.
            if (gauge.Song != Song.Wanderer)
                return false;

            var songRem = SongTimerSeconds;
            var empyRem = LevelChecked(EmpyrealArrow) ? GetCooldown(EmpyrealArrow).CooldownRemaining : 999f;

            if (rep == 2)
            {
                if (BuffWindow)
                    return true;

                // Dump before song ends so we don't lose stacks.
                if (songRem <= 6.0f)
                    return true;

                // If Empyreal is about to be weaved, spend PP now so we don't end up choosing between them.
                if (empyRem <= 2.0f)
                    return true;

                return false;
            }

            if (rep == 1)
            {
                // Very late dump to avoid losing the last stack when the song flips.
                if (songRem <= 2.5f)
                    return true;
            }

            return false;
        }


        //Sidewinder Logic
        internal static bool UsePooledSidewinder()
        {
            if (BuffWindow && RagingStrikesDuration < 18 || RagingCD > 30)
                    return true;
            
            return false;
        }

        //Bloodletter & Rain of Death Logic
        internal static bool UsePooledBloodRain()
        {
            if (!LevelChecked(Bloodletter))
                return false;

            // Ruthless Bloodletter/Rain of Death:
            // The #1 enemy is sitting on charges (especially during Mage's Ballad where procs can refill charges).
            // Spend aggressively, only holding when it meaningfully aligns with buffs without risking overcap.
            var maxCharges = LevelChecked(RainOfDeath) ? 2u : 1u;
            var charges = BloodletterCharges;

            if (charges == 0)
                return false;

            // Never overcap charges.
            if (charges >= maxCharges)
                return true;

            // During Mage's Ballad, procs can refill charges -> spend at 1 to avoid wasting procs.
            if (gauge.Song == Song.Mage)
                return true;

            // In buffs: spend (we prefer damage now over "perfect" alignment).
            if (BuffWindow)
                return true;

            // Otherwise, still spend if we have any charge to keep the wheel turning.
            // This is intentionally aggressive; Bard gains a lot from never letting BL/RoD sit idle.
            return true;
        }

        #endregion

        #region Dot Management
        //Iron Jaws dot refreshing
private static bool AllowIronJawsHardGate(out string reason)
{
    reason = string.Empty;

    if (!ActionReady(IronJaws))
    {
        reason = "IronJaws not ready";
        return false;
    }

    var hasPurple = Purple is not null;
    var hasBlue = Blue is not null;

    // Missing DoT(s): DO NOT use Iron Jaws. It only extends existing DoTs; use Stormbite/Caustic Bite instead.
    if (!hasPurple || !hasBlue)
    {
        reason = "blocked: missing DoT(s) (use bites, not Iron Jaws)";
        return false;
    }
    var purple = PurpleRemaining;
    var blue = BlueRemaining;

    // Hard forbid: never refresh early when both DoTs have plenty of time left.
    if (purple > 6f && blue > 6f)
    {
        reason = $"blocked early (purple={purple:0.0}s, blue={blue:0.0}s)";
        return false;
    }

    // Allow only when DoTs are expiring soon.
    if (purple <= 3.5f || blue <= 3.5f)
    {
        reason = $"allowed late (purple={purple:0.0}s, blue={blue:0.0}s)";
        return true;
    }

    reason = $"blocked mid (purple={purple:0.0}s, blue={blue:0.0}s)";
    return false;
}
        //Iron Jaws dot refreshing
        

// Hard gate for Iron Jaws when evaluating a specific target (used by multidot retargeting).
private static bool AllowIronJawsHardGate(IGameObject? target, ushort blueDebuff, ushort purpleDebuff, out string reason)
{
    reason = string.Empty;

    if (target is null)
    {
        reason = "blocked: null target";
        return false;
    }

    if (!ActionReady(IronJaws))
    {
        reason = "IronJaws not ready";
        return false;
    }

    // Iron Jaws only refreshes existing DoTs.
    var hasBlue = HasStatusEffect(blueDebuff, target);
    var hasPurple = HasStatusEffect(purpleDebuff, target);

    if (!hasBlue || !hasPurple)
    {
        reason = "blocked: missing DoT(s) on target (use bites)";
        return false;
    }

    var blueRem = GetStatusEffectRemainingTime(GetStatusEffect(blueDebuff, target));
    var purpleRem = GetStatusEffectRemainingTime(GetStatusEffect(purpleDebuff, target));

    // Hard forbid: both DoTs still healthy.
    if (blueRem > 6f && purpleRem > 6f)
    {
        reason = $"blocked: too early (blue={blueRem:0.0}s, purple={purpleRem:0.0}s)";
        return false;
    }

    // Allow only late refresh window.
    if (blueRem <= 3.5f || purpleRem <= 3.5f)
    {
        reason = $"allowed late (blue={blueRem:0.0}s, purple={purpleRem:0.0}s)";
        return true;
    }

    reason = $"blocked: waiting (blue={blueRem:0.0}s, purple={purpleRem:0.0}s)";
    return false;
}


// Iron Jaws hard-gate evaluation gets called extremely frequently (every framework tick).
// Cache the result per-GCD (or at least per ~250ms) to prevent log spam and reduce hitching.
private static bool _ijGateCachedValid;
private static float _ijGateCachedGcdRemaining;
private static long _ijGateCachedEvalMs;
private static bool _ijGateCachedAllowed;
private static string _ijGateCachedReason = string.Empty;

private static long _ijGateLastLogMs;
private static bool _ijGateLastLoggedAllowed;
private static string _ijGateLastLoggedReason = string.Empty;
private static string _ijGateLastLoggedReasonKey = string.Empty;

private static bool AllowIronJawsHardGateCached(out string reason)
{
    var nowMs = Environment.TickCount64;

    // RemainingGCD drops during a GCD, then jumps up when a new GCD begins.
    // We treat a noticeable jump up as "new GCD window" and invalidate the cache.
    var gcdRem = RemainingGCD;

    var newGcdDetected = _ijGateCachedValid && (gcdRem > _ijGateCachedGcdRemaining + 0.20f);

    // Also invalidate if we haven't evaluated in a bit (safety valve).
    var stale = _ijGateCachedValid && (nowMs - _ijGateCachedEvalMs > 250);

    if (!_ijGateCachedValid || newGcdDetected || stale)
    {
        _ijGateCachedAllowed = AllowIronJawsHardGate(out _ijGateCachedReason);
        _ijGateCachedEvalMs = nowMs;
        _ijGateCachedGcdRemaining = gcdRem;
        _ijGateCachedValid = true;
    }
    else
    {
        // Keep tracking current remaining GCD so "jump up" detection works reliably.
        _ijGateCachedGcdRemaining = gcdRem;
    }

    reason = _ijGateCachedReason;
    return _ijGateCachedAllowed;
}

private static void TraceIronJawsGate(bool allowed, string reason)
{
    // Reduce log spam: only emit when the decision or normalized reason changes.
    // (No periodic heartbeat spam while idle / between refresh windows.)
    var nowMs = Environment.TickCount64;
    var stateChanged = allowed != _ijGateLastLoggedAllowed;

    // Normalize numeric parts (timers) so we don't treat every 0.01s tick as a "reason change".
    // Also drop the "(refresh)" prefix so the shared gate doesn't double-log.
    var reasonKeyRaw = reason ?? string.Empty;
    reasonKeyRaw = reasonKeyRaw.Replace("(refresh)", string.Empty, StringComparison.OrdinalIgnoreCase).Trim();
    var reasonKey = System.Text.RegularExpressions.Regex.Replace(reasonKeyRaw, @"\d+(?:\.\d+)?", "#");
    var reasonChanged = !string.Equals(reasonKey, _ijGateLastLoggedReasonKey, StringComparison.Ordinal);

    // Always log state flips. Only log reason changes at most once per second.
    var shouldLog = stateChanged || (reasonChanged && (nowMs - _ijGateLastLogMs) >= 1000);
    if (shouldLog)
    {
        PluginLog.Information($"[BRD.Adv] UseIronJaws gate: {(allowed ? "ALLOW" : "BLOCK")} | {reasonKeyRaw}");
        _ijGateLastLogMs = nowMs;
        _ijGateLastLoggedAllowed = allowed;
        _ijGateLastLoggedReasonKey = reasonKey;
    }
}


internal static bool UseIronJaws()
{
    // Avoid spamming debug output (and wasting cycles) when we're not actually fighting anything.
    if (!InCombat() || CurrentTarget == null)
        return false;


    var allowed = AllowIronJawsHardGateCached(out var reason);

    TraceIronJawsGate(allowed, reason);

    return allowed;
}
        //Blue dot application and low level refresh
        internal static bool ApplyBlueDot()
        {
            return ActionReady(Windbite) && DebuffCapCanBlue && (Blue is null || !CanIronJaws && BlueRemaining < 3.2f);
        }
        //Purple dot application and low level refresh
        internal static bool ApplyPurpleDot()
        {
            return ActionReady(VenomousBite) && DebuffCapCanPurple && (Purple is null || !CanIronJaws && PurpleRemaining < 3.2f);
        }
        //Raging jaws option dot refresh for snapshot
        internal static bool RagingJawsRefresh()
{
    // Refresh logic uses the same hard-gate; keep it cached to avoid per-frame re-eval/logging.
    var allowed = AllowIronJawsHardGateCached(out var reason);

	TraceIronJawsGate(allowed, $"(refresh) {reason}");

    return allowed;
}
        #endregion

        #region Buff Timing
        //RadiantFinale Buff
        internal static bool UseRadiantBuff()
        {
	            // Throughput-first: don't miss Radiant uses due to tiny timing windows.
	            // Prefer aligning into/near Raging Strikes, but never hard-block for long.
	            if (!CanUseRadiantFinaleNow())
	                return false;

	            if (HasStatusEffect(Buffs.RagingStrikes))
	                return true;

	            // Cast shortly before RS comes up (or if RS is ready but not yet pressed).
	            return RagingCD < 8f || ActionReady(RagingStrikes);
        } 
        //BattleVoice Buff
        internal static bool UseBattleVoiceBuff()
        {
	            if (!ActionReady(BattleVoice))
	                return false;

	            // Prefer inside Radiant/RS, but don't chain-lock buffs behind each other.
	            if (HasStatusEffect(Buffs.RagingStrikes) || HasStatusEffect(Buffs.RadiantFinale))
	                return true;

	            return RagingCD < 8f || ActionReady(RagingStrikes);
        }
        //RagingStrikes Buff
        internal static bool UseRagingStrikesBuff()
        {
	            if (!ActionReady(RagingStrikes))
	                return false;

	            // If BV is available, prefer BV first; otherwise don't stall RS.
	            if (LevelChecked(BattleVoice) && ActionReady(BattleVoice))
	                return false;

	            return true;
        } 
        //Barrage Buff
        internal static bool UseBarrageBuff()
        {
            return ActionReady(Barrage) && HasStatusEffect(Buffs.RagingStrikes) && !HasStatusEffect(Buffs.ResonantArrowReady);
        }
        #endregion
    
        #region Songs

        internal static bool TryGetForcedNextSong(out uint nextSongAction)
        {
            nextSongAction = 0;
            if (gauge == null) return false;

            // Zero SongNone time: immediately start a song if none is active.
            if (SongNone)
            {
                if (ActionReady(WanderersMinuet)) nextSongAction = WanderersMinuet;
                else if (ActionReady(MagesBallad)) nextSongAction = MagesBallad;
                else if (ActionReady(ArmysPaeon)) nextSongAction = ArmysPaeon;

                if (nextSongAction != 0)
                {
                    AdvTrace($"SongNone -> start song actionId={nextSongAction}");
                    return true;
                }
                return false;
            }

            // Song Rotation Lock: if the current song is ending, the next weave must be the next song.
            if (SongTimerSeconds <= 1.5f)
            {
                if (SongWanderer && ActionReady(MagesBallad)) nextSongAction = MagesBallad;
                else if (SongMage && ActionReady(ArmysPaeon)) nextSongAction = ArmysPaeon;
                else if (SongArmy && ActionReady(WanderersMinuet)) nextSongAction = WanderersMinuet;

                if (nextSongAction != 0)
                {
                    AdvTrace($"SongLock current={gauge.Song} rem={SongTimerSeconds:0.0}s -> actionId={nextSongAction}");
                    return true;
                }
            }

            return false;
        }

        internal static bool WandererSong()
{
    if (!ActionReady(WanderersMinuet))
        return false;

    if (!(CanBardWeave || !BardHasTarget))
        return false;

    // Zero SongNone time: start Wanderer's first when no song is active.
    if (SongNone)
        return true;

    // Song rotation (modern BRD): we *clip Army's Paeon early* so Wanderer's can come back on cooldown.
    // Typical timing: WM (t=0) -> MB (t=45) -> AP (t=90). WM recast is 120s, so it's ready again with ~15s left on AP.
    // Letting AP run full duration delays WM, loses Pitch Perfect windows, and generally feels like griefing.
    if (SongArmy && SongTimerSeconds <= 16f)
        return true;

    return false;
}
        internal static bool MagesSong()
{
    if (!ActionReady(MagesBallad))
        return false;

    if (!(CanBardWeave || !BardHasTarget))
        return false;

    // If we have no song and Wanderer's isn't available, use Mage's.
    if (SongNone && !ActionReady(WanderersMinuet))
        return true;

    // Song Rotation Lock: transition at the end of Wanderer's.
    if (SongWanderer && SongTimerSeconds <= 1.5f)
        return true;

    return false;
}
        internal static bool ArmySong()
{
    if (!ActionReady(ArmysPaeon))
        return false;

    if (!(CanBardWeave || !BardHasTarget))
        return false;

    // If we have no song and neither Wanderer's nor Mage's are available, use Army's as last resort.
    if (SongNone && !ActionReady(MagesBallad) && !ActionReady(WanderersMinuet))
        return true;

    // Song Rotation Lock: transition at the end of Mage's.
    if (SongMage && SongTimerSeconds <= 1.5f)
        return true;

    return false;
}
        internal static bool SongChangeEmpyreal()
{
    // Use Empyreal before transitioning to Army if we have time; never override the hard song lock.
    return SongMage &&
           SongTimerSeconds <= 3f &&
           SongTimerSeconds > 1.5f &&
           ActionReady(ArmysPaeon) &&
           ActionReady(EmpyrealArrow) &&
           BardHasTarget &&
           CanBardWeave;
}
        internal static bool SongChangePitchPerfect()
{
    // Dump Pitch Perfect stacks before transitioning to Mage's if we have time; never override the hard song lock.
    return SongWanderer &&
           SongTimerSeconds <= 3f &&
           SongTimerSeconds > 1.5f &&
           gauge.Repertoire > 0 &&
           BardHasTarget &&
           CanBardWeave;
}
        #endregion

        #region Warden Resolver
        [ActionRetargeting.TargetResolver]
        private static IGameObject? WardenResolver() =>
            GetPartyMembers()
                .Select(member => member.BattleChara)          
                .FirstOrDefault(member => member.IsNotThePlayer() && !member.IsDead && member.IsCleansable() && InActionRange(TheWardensPaeon, member));
        #endregion
        
    #endregion

    #region ID's

    public const uint
        HeavyShot = 97,
        StraightShot = 98,
        VenomousBite = 100,
        RagingStrikes = 101,
        QuickNock = 106,
        Barrage = 107,
        Bloodletter = 110,
        Windbite = 113,
        MagesBallad = 114,
        ArmysPaeon = 116,
        RainOfDeath = 117,
        BattleVoice = 118,
        EmpyrealArrow = 3558,
        WanderersMinuet = 3559,
        IronJaws = 3560,
        TheWardensPaeon = 3561,
        Sidewinder = 3562,
        PitchPerfect = 7404,
        Troubadour = 7405,
        CausticBite = 7406,
        Stormbite = 7407,
        NaturesMinne = 7408,
        RefulgentArrow = 7409,
        BurstShot = 16495,
        ApexArrow = 16496,
        Shadowbite = 16494,
        Ladonsbite = 25783,
        BlastArrow = 25784,
        RadiantFinale = 25785,
        WideVolley = 36974,
        HeartbreakShot = 36975,
        ResonantArrow = 36976,
        RadiantEncore = 36977;

    public static class Buffs
    {
        public const ushort
            RagingStrikes = 125,
            Barrage = 128,
            MagesBallad = 135,
            ArmysPaeon = 137,
            BattleVoice = 141,
            NaturesMinne = 1202,
            WanderersMinuet = 2216,
            Troubadour = 1934,
            BlastArrowReady = 2692,
            RadiantFinale = 2722,
            ShadowbiteReady = 3002,
            HawksEye = 3861,
            ResonantArrowReady = 3862,
            RadiantEncoreReady = 3863;
    }

    public static class Debuffs
    {
        public const ushort
            VenomousBite = 124,
            Windbite = 129,
            CausticBite = 1200,
            Stormbite = 1201;
    }

    internal static class Traits
    {
        internal const ushort
            EnhancedBloodletter = 445;
    }

    #endregion

    #region Openers
    public static BRDStandard Opener1 = new();
    public static BRDAdjusted Opener2 = new();
    public static BRDComfy Opener3 = new();
    internal static WrathOpener Opener()
    {
        if (IsEnabled(Preset.BRD_ST_AdvMode))
        {
            if (BRD_Adv_Opener_Selection == 0 && Opener1.LevelChecked) return Opener1;
            if (BRD_Adv_Opener_Selection == 1 && Opener2.LevelChecked) return Opener2;
            if (BRD_Adv_Opener_Selection == 2 && Opener3.LevelChecked) return Opener3;
        }
        return Opener1.LevelChecked ? Opener1 : WrathOpener.Dummy;
    }

    internal class BRDStandard : WrathOpener
    {
        public override List<uint> OpenerActions { get; set; } =
        [
            Stormbite,
            WanderersMinuet,
            EmpyrealArrow,
            CausticBite,
            BattleVoice,
            BurstShot,
            RadiantFinale,
            RagingStrikes,
            BurstShot,
            RadiantEncore,
            Barrage,
            RefulgentArrow,
            Sidewinder,
            ResonantArrow,
            EmpyrealArrow,
            BurstShot,
            BurstShot,
            IronJaws,
            BurstShot
        ];
        public override List<(int[], uint, Func<bool>)> SubstitutionSteps { get; set; } =
        [
            ([6, 9, 16, 17, 19], RefulgentArrow, () => HasStatusEffect(Buffs.HawksEye))
        ];
        public override List<int> DelayedWeaveSteps { get; set; } =
        [
            5
        ];
        public override int MinOpenerLevel => 100;
        public override int MaxOpenerLevel => 109;

        public override Preset Preset => Preset.BRD_ST_Adv_Balance_Standard;

        internal override UserData ContentCheckConfig => BRD_Balance_Content;
        public override bool HasCooldowns() =>
            IsOffCooldown(WanderersMinuet) &&
            IsOffCooldown(BattleVoice) &&
            IsOffCooldown(RadiantFinale) &&
            IsOffCooldown(RagingStrikes) &&
            IsOffCooldown(Barrage) &&
            IsOffCooldown(Sidewinder);
    }
    internal class BRDAdjusted : WrathOpener
    {
        public override List<uint> OpenerActions { get; set; } =
        [
            HeartbreakShot,
            Stormbite,
            WanderersMinuet,
            EmpyrealArrow,
            CausticBite,
            BattleVoice,
            BurstShot,
            RadiantFinale,
            RagingStrikes,
            BurstShot,
            Barrage,
            RefulgentArrow,
            Sidewinder,
            RadiantEncore,
            ResonantArrow,
            EmpyrealArrow,
            BurstShot,
            BurstShot,
            IronJaws,
            BurstShot
        ];
        public override List<(int[], uint, Func<bool>)> SubstitutionSteps { get; set; } =
        [
            ([7, 10, 17, 18, 20], RefulgentArrow, () => HasStatusEffect(Buffs.HawksEye))
        ];
        public override List<int> DelayedWeaveSteps { get; set; } =
        [
            6
        ];
        public override int MinOpenerLevel => 100;
        public override int MaxOpenerLevel => 109;

        public override Preset Preset => Preset.BRD_ST_Adv_Balance_Standard;

        internal override UserData ContentCheckConfig => BRD_Balance_Content;
        public override bool HasCooldowns() =>
            IsOffCooldown(WanderersMinuet) &&
            IsOffCooldown(BattleVoice) &&
            IsOffCooldown(RadiantFinale) &&
            IsOffCooldown(RagingStrikes) &&
            IsOffCooldown(Barrage) &&
            IsOffCooldown(Sidewinder);
    }
    internal class BRDComfy : WrathOpener
    {
        public override List<uint> OpenerActions { get; set; } =
        [
            Stormbite,
            HeartbreakShot,
            WanderersMinuet,
            CausticBite,
            EmpyrealArrow,
            RadiantFinale,
            BurstShot,
            BattleVoice,
            RagingStrikes,
            BurstShot,
            Barrage,
            RefulgentArrow,
            Sidewinder,
            RadiantEncore,
            ResonantArrow,
            BurstShot,
            EmpyrealArrow,
            BurstShot,
            IronJaws,
            BurstShot
        ];
        public override List<(int[], uint, Func<bool>)> SubstitutionSteps { get; set; } =
        [
            ([7, 10, 16, 18, 20], RefulgentArrow, () => HasStatusEffect(Buffs.HawksEye))
        ];
        public override int MinOpenerLevel => 100;
        public override int MaxOpenerLevel => 109;
        public override Preset Preset => Preset.BRD_ST_Adv_Balance_Standard;
        internal override UserData ContentCheckConfig => BRD_Balance_Content;
        public override bool HasCooldowns() =>
            IsOffCooldown(WanderersMinuet) &&
            IsOffCooldown(BattleVoice) &&
            IsOffCooldown(RadiantFinale) &&
            IsOffCooldown(RagingStrikes) &&
            IsOffCooldown(Barrage) &&
            IsOffCooldown(Sidewinder);
    }
    #endregion
}