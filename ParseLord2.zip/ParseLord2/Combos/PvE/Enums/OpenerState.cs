﻿namespace ParseLord2.Combos.PvE.Enums;

public enum OpenerState
{
    OpenerNotReady,
    OpenerReady,
    InOpener,
    OpenerFinished,
    FailedOpener
}
