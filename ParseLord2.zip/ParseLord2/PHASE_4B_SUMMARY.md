# Phase 4B: Burst-Safe Filler Logic for DRG

## Implementation Summary

Phase 4B adds intelligent burst-safe filler logic to DRG's oGCD planner. During PreBurst phase (when burst buffs are about to align), the system now holds non-urgent oGCDs to preserve weave slots for the upcoming burst window, while still allowing urgent actions that prevent resource overcaps or buff expiry.

## What Changed

### File Modified
- `AutoRotation/Planner/Dragoon/DrgOgcdPlanner.cs`

### Core Logic: Urgency-Based Filtering During PreBurst

During `BurstPhase.PreBurst`, oGCDs are now categorized as:

#### URGENT (Always Allowed)
These actions must be used to prevent loss of resources/procs:
- **LotD Window Abilities** (Nastrond, Stardiver, Starcross, Rise of the Dragon)
  - LotD window is time-limited (~20s)
  - Missing these means lost potency
- **Wyrmwind Thrust** (when Firstminds == 2 stacks)
  - Prevents overcapping Firstminds Focus
- **Mirage Dive** (when Dive Ready buff active)
  - Buff has limited duration (~15s)
- **High Jump** (conditional urgency)
  - Urgent when Dive Ready buff < 3s remaining (need to refresh)
  - Held during PreBurst when Dive Ready > 3s (no urgency)
- **Life Surge** (when next GCD is worthy)
  - Already conditional on worthy GCD
  - Natural urgency from GCD alignment
- **Lance Charge / Battle Litany**
  - These ARE the burst triggers
  - Always allowed (with existing alignment logic)

#### NON-URGENT (Held During PreBurst)
These actions can safely wait for the burst window:
- **Dragonfire Dive**
  - 120s cooldown, no overcap risk
  - No proc/buff dependencies
  - **Held during PreBurst** with reason: "Held for upcoming burst (no urgency)"
- **Geirskogul** (when not in LotD)
  - 30s cooldown, no overcap risk
  - **Held during PreBurst** with reason: "Held for upcoming burst (no urgency)"

### Enhanced Debug Tracing

All oGCD candidates now have comprehensive `BlockReason` implementations that explain:
- Why abilities are blocked
- When abilities are being held for burst
- What conditions are preventing execution

Examples of new trace messages:
- "Held for upcoming burst (no urgency)"
- "Held for upcoming burst (Dive Ready not urgent)"
- "Holding to align with Battle Litany"
- "Firstminds not capped"
- "Dive Ready buff not active"
- "Life Surge buff already active"
- "Next GCD not worthy of Life Surge"

## How It Works

### PreBurst Detection (Existing Phase 4A Logic)
PreBurst phase is active when:
- One buff (Litany or Lance) is ready AND
- The other buff will be ready within 5 seconds

### Weave Slot Preservation (New Phase 4B Logic)
During PreBurst:
1. Non-urgent oGCDs are blocked via `HardOk` returning false
2. `BlockReason` provides clear explanation for the trace UI
3. Urgent oGCDs continue to execute normally
4. Burst buffs (Litany/Lance) execute when ready (with alignment logic)

### Result
- Weave slots are preserved for the upcoming burst
- No resource overcaps or proc/buff expiry
- All decisions are explainable via Hybrid Planner Trace UI

## Testing Recommendations

### Verify Burst Windows
1. Start combat on a striking dummy
2. Watch for PreBurst phase activation (when one buff is ready, other ~5s away)
3. Confirm that Dragonfire Dive and Geirskogul show as "Held for upcoming burst" in trace
4. Confirm that Lance Charge + Battle Litany fire together
5. Verify that during burst window (InBurst), all abilities execute normally

### Verify Urgency Overrides
1. During PreBurst, generate Dive Ready buff with High Jump
2. Let Dive Ready timer drop to < 3 seconds remaining
3. Confirm High Jump becomes allowed again (trace should NOT show held message)
4. Confirm Mirage Dive executes normally during PreBurst (urgent)

### Verify Resource Handling
1. Build Firstminds Focus to 2 stacks during PreBurst
2. Confirm Wyrmwind Thrust executes (urgent - overcap prevention)
3. Enter LotD during PreBurst
4. Confirm all LotD abilities execute normally (urgent - window limited)

### Check Trace UI
1. Open Debug tab → Hybrid Planner Trace
2. During PreBurst:
   - Dragonfire Dive should show: Allowed=false, BlockReason="Held for upcoming burst (no urgency)"
   - Geirskogul should show: Allowed=false, BlockReason="Held for upcoming burst (no urgency)"
   - High Jump should show held message UNLESS Dive Ready < 3s
3. All trace messages should be clear and explain the decision

## Future Iteration Opportunities

### Phase 4C Candidates (Not Implemented Yet)
- Integrate LotD into burst phase detection (currently only Litany/Lance define burst)
- Add PostBurst phase logic (wind down after buff windows expire)
- Extend filler hold logic to other jobs
- Add configurable urgency thresholds (currently hardcoded)
- Consider resource projection (e.g., "will Firstminds cap within 2 GCDs?")

### Phase 5+ Candidates (Not Implemented Yet)
- Priority Stack integration for candidate generation
- AoE Gold Planner variant for DRG
- Multi-target rotation selection
- Support for other melee DPS jobs
- Advanced buff alignment (e.g., raid buff windows, potion timing)

## Notes

- This implementation is conservative by design
- All urgency thresholds are based on buff durations and resource caps
- The logic is DRG-specific but follows patterns that can extend to other jobs
- Burst phase detection remains simple (Litany/Lance only) for now
- All decisions remain explainable and debuggable via trace UI
