﻿global using Dalamud.Bindings.ImGui;
global using Preset = ParseLord2.Combos.Preset;
global using static ParseLord2.ParseLord2;