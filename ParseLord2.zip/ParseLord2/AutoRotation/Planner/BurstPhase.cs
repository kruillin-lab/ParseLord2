namespace ParseLord2.AutoRotation.Planner;

internal enum BurstPhase
{
    Neutral = 0,
    PreBurst = 1,
    InBurst = 2,
    PostBurst = 3
}
