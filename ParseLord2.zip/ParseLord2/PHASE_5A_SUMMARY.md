# Phase 5A: DRG AoE Gold Planner

## Implementation Summary

Phase 5A implements the AoE variant of the Gold Planner for DRG, providing deterministic multi-target rotation support. This completes the DRG Gold Planner coverage across both single-target and AoE scenarios.

## What Changed

### Files Created
- `AutoRotation/Planner/Dragoon/DrgAoeGcdPlanner.cs` - AoE GCD planner

### Files Modified
- `Combos/PvE/DRG/DRG.cs` - Added DRG_AOE_GoldPlanner combo class
- `Combos/CustomComboPreset.cs` - Added DRG_AOE_GoldPlanner preset enum (6250)

## Core Implementation

### 1. DRG AoE GCD Planner (`DrgAoeGcdPlanner.cs`)

The AoE GCD planner implements a simple, deterministic 3-step combo:

```
DoomSpike → SonicThrust → CoerthanTorment
```

**Key Features:**
- **Draconian Fire Integration**: Uses DraconianFury instead of DoomSpike when the buff is active
- **Level-Aware**: Handles pre-SonicThrust and pre-CoerthanTorment levels gracefully
- **Deterministic**: No branching, just a strict 3-GCD loop

**Comparison to ST Planner:**
- **Simpler**: No DoT/buff refresh decisions (AoE has no DoT)
- **Shorter Loop**: 3 GCDs vs 10 GCDs for ST
- **No Branching**: Single path vs dual-branch (Chaotic Spring / Heavens' Thrust)

### 2. DRG_AOE_GoldPlanner Combo Class

Follows the same integration pattern as ST Gold Planner:

```csharp
internal class DRG_AOE_GoldPlanner : CustomCombo
{
    protected internal override Preset Preset => Preset.DRG_AOE_GoldPlanner;
    
    private static readonly DrgAoeGcdPlanner Planner = new();
    private static readonly DrgOgcdPlanner OgcdPlanner = new();
    
    protected override uint Invoke(uint actionID)
    {
        // 1. Build planner context (targetCountEstimate: 3 for AoE)
        // 2. Get next GCD from AoE planner
        // 3. Try select oGCD (same logic as ST)
        // 4. Record trace to Debug UI
        // 5. Return oGCD if selected, else GCD
    }
}
```

**Target Count Estimate:**
- ST: `targetCountEstimate: 1`
- AoE: `targetCountEstimate: 3`
- This signals AoE mode to any future target-count-aware logic

### 3. oGCD Behavior in AoE Mode

**Current Behavior (Phase 5A):**
- oGCD selection uses the **same planner** as ST (`DrgOgcdPlanner`)
- Most oGCDs work identically for ST and AoE:
  - Buffs (Litany, Lance Charge)
  - LotD package (Nastrond, Stardiver, Starcross, Rise)
  - Wyrmwind Thrust
  - Mirage Dive
  - Life Surge
  
**Life Surge Targeting in AoE:**
Current Life Surge worthy GCDs:
```csharp
HeavensThrust, ChaoticSpring, Drakesbane, CoerthanTorment
```

CoerthanTorment (AoE finisher) is already marked as worthy, so Life Surge will correctly buff it during AoE rotation.

**Future Enhancement Opportunity:**
- Add AoE-specific scoring adjustments if needed
- Example: Prioritize Geirskogul/Nastrond more heavily during AoE (but this is likely unnecessary since they're already high-priority)

## AoE Rotation Structure

### 3-GCD Loop
```
1. DoomSpike (base) / DraconianFury (when buff active)
   ↓
2. SonicThrust (combo step 2)
   ↓
3. CoerthanTorment (finisher)
   ↓ (loop back to step 1)
```

### Power Surge Maintenance (Pre-SonicThrust Levels)
At low levels (before SonicThrust is learned), the planner falls back to repeating DoomSpike. The existing Advanced Mode handles Power Surge maintenance via ST combo when needed, but Gold Planner keeps it simple for now.

## Preset Configuration

**Enum ID:** `DRG_AOE_GoldPlanner = 6250`

**Attributes:**
- `[ReplaceSkill(DRG.DoomSpike)]` - Replaces Doom Spike button
- `[ConflictingCombos(DRG_AoE_SimpleMode, DRG_AoE_AdvancedMode)]` - Mutually exclusive
- `[AdvancedCombo]` - Marked as advanced feature
- `[AutoAction(false, false)]` - Not auto-enabled

**UI Location:**
Appears in DRG combo list between Simple Mode (6200) and Advanced Mode (6201)

## Debug Trace Integration

**Trace Key:** `"DRG_AOE_GoldPlanner"`

**Trace Label:** `"DRG AoE Gold Planner"`

The trace UI will show:
- Planned next GCD (DoomSpike/DraconianFury/SonicThrust/CoerthanTorment)
- Selected oGCD (if any)
- Target count estimate (3)
- Burst phase
- Weave window status
- oGCD candidate list with allowed/blocked status and scores

## Testing Recommendations

### Basic AoE Rotation
1. Enable DRG_AOE_GoldPlanner preset
2. Engage multiple enemies (3+)
3. Verify GCD sequence: DoomSpike → SonicThrust → CoerthanTorment → loop
4. Confirm Draconian Fire → DraconianFury replacement works

### oGCD Integration
1. Verify buffs (Litany/Lance) fire during AoE
2. Confirm Life Surge buffs CoerthanTorment
3. Check LotD abilities execute during AoE burst windows
4. Verify Wyrmwind, Mirage Dive, etc. work normally

### Burst Phase Behavior
1. Activate Litany/Lance during AoE
2. Verify BurstPhase = InBurst in trace
3. Confirm PreBurst filler holding works (Dragonfire/Geirskogul held)
4. Check PostBurst wind-down allows fillers

### Debug Trace
1. Open Debug tab → Hybrid Planner Trace
2. Select "DRG AoE Gold Planner" from dropdown (if multiple traces)
3. Verify all trace fields populated correctly
4. Check oGCD candidate list shows proper reasons

### Edge Cases
1. Test at low levels (pre-SonicThrust, pre-CoerthanTorment)
2. Verify combo continues correctly after stance dance or disconnect
3. Test with manual combo break (using different GCD mid-combo)

## Architecture Notes

### Code Reuse
- **oGCD Planner**: Fully shared between ST and AoE
- **Burst Detection**: Job-level, works for both modes
- **Trace System**: Generic, supports any planner variant
- **Context Building**: Same PlannerContext for both modes

### Target Count Awareness
Currently hardcoded in combo class:
```csharp
// ST
var ctx = PlannerContext.Build(..., targetCountEstimate: 1);

// AoE
var ctx = PlannerContext.Build(..., targetCountEstimate: 3);
```

**Future Enhancement:**
- Dynamic target count detection
- Automatic ST/AoE switching based on actual enemy count
- This would require engine-level target counting integration

### Separation of Concerns
- **GCD Planner**: Job/mode-specific (DrgGcdPlanner vs DrgAoeGcdPlanner)
- **oGCD Planner**: Job-specific, mode-agnostic (DrgOgcdPlanner shared)
- **Burst Detection**: Job-specific, mode-agnostic (PlannerContext shared)
- **Trace**: Generic infrastructure

## Comparison: ST vs AoE Gold Planner

| Aspect | ST Gold Planner | AoE Gold Planner |
|--------|-----------------|------------------|
| **GCD Loop** | 10 GCDs (dual-branch) | 3 GCDs (single path) |
| **Branching** | Yes (DoT/buff refresh) | No |
| **oGCD Logic** | DrgOgcdPlanner | DrgOgcdPlanner (shared) |
| **Burst Logic** | PlannerContext | PlannerContext (shared) |
| **Target Count** | 1 | 3 |
| **Complexity** | High | Low |
| **Button** | True Thrust | Doom Spike |

## Performance Expectations

**GCD Accuracy:**
- Should execute perfect 3-GCD loop with no drift
- Draconian Fire replacement should be frame-perfect

**oGCD Usage:**
- Identical to ST Gold Planner
- All Phase 4B/4C logic applies (PreBurst holding, burst alignment, etc.)

**DPS Parity:**
- Should match or exceed AoE Advanced Mode
- Simpler rotation = fewer decision points = more consistent execution

## Future Iteration Opportunities

### Phase 5B+ Candidates
- Dynamic ST/AoE switching based on actual target count
- AoE-specific oGCD scoring adjustments (if needed)
- AoE opener sequence (currently starts immediately)
- Power Surge maintenance integration for pre-SonicThrust levels

### Other Jobs (Phase 6+)
When implementing other jobs, AoE considerations:
- **NIN**: Doton placement, Death Blossom combo
- **MNK**: Rockbreaker combo, AoE positionals
- **SAM**: Fuga/Mangetsu/Oka combo, Tenka Goken
- **RPR**: Spinning Scythe combo, Guillotine

## Known Limitations

1. **No Dynamic Mode Switching:**
   - User must manually toggle between ST and AoE Gold Planners
   - Cannot automatically switch based on target count

2. **Hardcoded Target Count:**
   - AoE mode uses `targetCountEstimate: 3` regardless of actual count
   - Future enhancement: Read actual target count from game state

3. **Pre-SonicThrust Levels:**
   - Basic fallback (repeat DoomSpike)
   - Advanced Mode has better Power Surge maintenance at low levels
   - Consider adding ST combo integration for sub-40 leveling

4. **No AoE Opener:**
   - Starts rotation immediately
   - No pre-pull or opener sequence specific to AoE

## Notes

- Phase 5A completes DRG Gold Planner coverage (ST + AoE)
- Architecture proven to scale: Adding AoE required only ~50 lines of new GCD planner code
- oGCD logic, burst detection, and trace system all reused without modification
- Next logical step: Implement another job to validate cross-job scalability (Phase 5B)
