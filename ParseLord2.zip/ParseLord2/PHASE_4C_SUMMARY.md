# Phase 4C: Enhanced Burst Detection for DRG

## Implementation Summary

Phase 4C enhances the burst phase detection system by integrating Life of the Dragon (LotD) into the burst logic and implementing the PostBurst phase for proper wind-down behavior after burst windows end.

## What Changed

### Files Modified
- `AutoRotation/Planner/PlannerContext.cs` - Enhanced burst detection logic
- `AutoRotation/Planner/Dragoon/DrgOgcdPlanner.cs` - Updated comments for PostBurst

### Core Changes

#### 1. Life of the Dragon Integration

**Previous Behavior:**
- InBurst phase only activated when Litany OR Lance Charge buffs were active
- LotD window (~20s major damage phase) was not considered for burst detection

**New Behavior:**
- InBurst phase now activates when:
  - Battle Litany buff is active OR
  - Lance Charge buff is active OR
  - **Life of the Dragon is active**
- LotD is checked via `gauge.IsLOTDActive` (job-specific gauge check)

**Why This Matters:**
- LotD is a ~20 second window where DRG uses high-potency abilities (Nastrond x3, Stardiver, etc.)
- These abilities were already marked as urgent in Phase 4B
- Now the entire LotD window is recognized as InBurst, improving overall burst recognition

#### 2. PostBurst Phase Implementation

**Detection Logic:**
PostBurst phase activates after major buff windows expire, providing a wind-down period:

- **Battle Litany PostBurst Window:**
  - Duration: 15s, Cooldown: 120s
  - When buff ends, CD remaining = 105s
  - PostBurst active when: CD is 95-105s (10 second window)
  
- **Lance Charge PostBurst Window:**
  - Duration: 20s, Cooldown: 90s
  - When buff ends, CD remaining = 70s
  - PostBurst active when: CD is 60-70s (10 second window)

**Behavior During PostBurst:**
- Non-urgent oGCDs (Dragonfire Dive, Geirskogul) are no longer held
- Acts similar to Neutral phase for filler execution
- Allows abilities to be used during the wind-down period after burst ends

#### 3. Updated Burst Phase Hierarchy

```
Priority (High to Low):
1. InBurst    → Litany OR Lance OR LotD active
2. PreBurst   → One buff ready, other within 5s (alignment window)
3. PostBurst  → Recently exited buff window (10s wind-down)
4. Neutral    → Standard operation
```

## Burst Phase State Machine

```
Neutral ─────────────────────────────────────────────────────┐
   │                                                          │
   │ (One buff ready, other ~5s away)                        │
   ▼                                                          │
PreBurst ─── (Both buffs align + fire) ──────────┐          │
   │                                               │          │
   │ (Buffs active OR LotD active)                │          │
   ▼                                               │          │
InBurst ──── (Buffs expire) ───────────────────► │          │
   │                                               │          │
   │                                               ▼          │
   │                                          PostBurst ──────┘
   │                                          (10s wind-down)
   │
   │ (LotD activates during neutral/filler)
   └────────────────────────────────────────────────►
```

## oGCD Behavior Matrix

| Ability | PreBurst | InBurst | PostBurst | Neutral |
|---------|----------|---------|-----------|---------|
| **Litany/Lance** | Execute (when aligned) | Execute | - | - |
| **LotD Abilities** | Execute (urgent) | Execute | - | - |
| **Wyrmwind @ cap** | Execute (urgent) | Execute | Execute | Execute |
| **Mirage Dive** | Execute (urgent) | Execute | Execute | Execute |
| **High Jump** | Conditional* | Execute | Execute | Execute |
| **Dragonfire Dive** | **HELD** | Execute | Execute | Execute |
| **Geirskogul** | **HELD** | Execute | Execute | Execute |
| **Life Surge** | When worthy GCD | Execute | Execute | Execute |

*High Jump: Held during PreBurst unless Dive Ready buff < 3s (prevents proc loss)

## Implementation Notes

### Job-Specific Detection
The burst detection is currently DRG-specific:
- Hardcoded status IDs for Litany (786) and Lance (1864)
- Hardcoded action IDs for Litany (3557) and Lance (85)
- Job check: `Player.Object?.ClassJob.GameData?.Abbreviation == "DRG"`
- Gauge access: `GetJobGauge<DRGGauge>()`

When expanding to other jobs, this section will need to be refactored into job-specific burst detectors.

### PostBurst Timing Calculations
The PostBurst window is based on ability cooldown tracking:
- Window duration: 10 seconds
- Calculated from buff duration and total cooldown
- Formula: `justEnded = !buffActive && cd <= (totalCd - buffDuration) && cd > (totalCd - buffDuration - postBurstWindow)`

This approach works without needing historical buff tracking.

## Testing Recommendations

### Verify LotD Burst Recognition
1. Enter Life of the Dragon during combat
2. Check Debug tab → Hybrid Planner Trace
3. Verify BurstPhase shows "InBurst" during LotD
4. Confirm LotD abilities (Nastrond, Stardiver, Starcross, Rise) execute normally
5. Verify non-urgent fillers still execute during LotD (already InBurst)

### Verify PostBurst Phase
1. Use Battle Litany and let it expire completely
2. Observe the 10-second window after buff ends
3. Check trace: BurstPhase should show "PostBurst"
4. Verify Dragonfire Dive and Geirskogul are allowed (not held)
5. Repeat test with Lance Charge

### Verify Phase Transitions
1. Start in Neutral
2. Get one buff ready, other ~5s away → PreBurst
3. Fire both buffs together → InBurst
4. Wait for buffs to expire → PostBurst
5. Wait 10s → back to Neutral

### Edge Case: LotD During Preburst/Neutral
1. Activate LotD while in Neutral (no Litany/Lance active)
2. Verify phase changes to InBurst
3. Confirm LotD abilities execute properly
4. Verify non-urgent fillers are NOT held (already in InBurst from LotD)

## Impact on DPS

**Positive Impacts:**
- LotD window now properly recognized as burst
- Better burst phase coverage (Litany + Lance + LotD all contribute)
- PostBurst wind-down prevents holding oGCDs unnecessarily after burst ends
- More accurate burst phase timing improves oGCD priority decisions

**No Expected Negatives:**
- All Phase 4B urgency logic remains intact
- Resource management unchanged
- Burst alignment logic unchanged

## Future Iteration Opportunities

### Phase 5+ Candidates
- Refactor burst detection into job-specific strategies
- Add configurable PostBurst window duration
- Consider raid buff alignment (party member buffs)
- Add pre-LotD burst alignment (hold Litany/Lance for LotD entry)
- Implement opener-specific burst logic

### Other Jobs
When implementing other jobs, burst detection patterns to consider:
- **NIN**: Trick Attack windows, Mug/Bunshin alignment
- **MNK**: Riddle of Fire + Brotherhood windows
- **SAM**: Tsubame-gaeshi availability, Meikyo/Kaiten windows
- **RPR**: Enshroud windows, Arcane Circle alignment

## Notes

- PostBurst detection uses cooldown remaining time as a proxy for "buff just expired"
- This is reliable because buffs have fixed durations and cooldowns
- Job-specific check prevents gauge access errors on non-DRG jobs
- All burst logic remains explainable via PlannerContext → trace UI
- Implementation remains conservative and safe to iterate
